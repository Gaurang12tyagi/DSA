// TIME COMPLEXITY----->O(N)
#include <iostream>
using namespace std;
class array_insertion
{
public:
    int insertion(int n, int arr[], int index, int capacity, int value)
    {
        if (n >= capacity)
        {
            cout << "ELEMENT CAN'T BE STORED AS ARRAY IS FULL" << endl;
            return -1;
        }
        for (int i = n - 1; i >= index; i--)
        {
            arr[i + 1] = arr[i];
        }
        arr[index] = value;
    }
    void traversal(int arr[], int n)
    {
        for (int i = 0; i < n; i++)
        {
            cout << arr[i] << "  ";
        }
        cout << endl;
    }
};
int main()
{
    array_insertion obj;
    cout << "ENTER ARRAY SIZE : " << endl;
    int n;
    cin >> n;
    cout << "ENTER ARRAY ELEMENTS" << endl;
    int arr[20];
    for (int i = 0; i < n; i++)
    {
        cin >> arr[i];
    }
    cout << "ENTER INDEX :" << endl;
    int index;
    cin >> index;
    cout << "ENTER VAL :" << endl;
    int val;
    cin >> val;

    obj.insertion(n, arr, index, 20, val);
    n += 1;
    obj.traversal(arr, n);

    return 0;
}