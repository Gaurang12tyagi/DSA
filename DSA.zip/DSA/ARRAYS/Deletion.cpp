// TIME COMPLEXITY----->O(N)
#include <iostream>
using namespace std;
class array_deletion
{
public:
    void deletion(int n, int arr[], int index)
    {

        for (int i = index; i < n - 1; i++)
        {
            arr[i] = arr[i + 1];
        }
    }
    void traversal(int arr[], int n)
    {
        for (int i = 0; i < n; i++)
        {
            cout << arr[i] << "  ";
        }
        cout << endl;
    }
};
int main()
{
    array_deletion obj;
    cout << "ENTER ARRAY SIZE : " << endl;
    int n;
    cin >> n;
    cout << "ENTER ARRAY ELEMENTS" << endl;
    int arr[20];
    for (int i = 0; i < n; i++)
    {
        cin >> arr[i];
    }
    cout << "ENTER INDEX :" << endl;
    int index;
    cin >> index;
    obj.deletion(n, arr, index);
    n -= 1;
    obj.traversal(arr, n);

    return 0;
}