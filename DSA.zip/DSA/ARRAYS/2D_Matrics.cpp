#include <iostream>
using namespace std;
void matrics(int n, int arr1[], int arr2[])
{
    int new_arr[n];
    for (int i = 0; i < n; i++)
    {
        new_arr[i] = arr1[i] + arr2[i];
    }
    for (int i = 0; i < n; i++)
    {
        cout << new_arr[i] << " ";
    }
}
int main()
{
    cout << "ENTER THE SIZE OF THE TWO AYYAYS" << endl;
    int n;
    cin >> n;
    cout << "ENTER ARRAY 1 VALUES " << endl;
    int array1[n];
    for (int i = 0; i < n; i++)
    {
        cin >> array1[i];
    }
    cout << "ENTER ARRAY 2 VALUES " << endl;
    int array2[n];
    for (int i = 0; i < n; i++)
    {
        cin >> array2[i];
    }
    cout << "SUM OF ARRAYS IS " << endl;
    matrics(n, array1, array2);

    return 0;
}