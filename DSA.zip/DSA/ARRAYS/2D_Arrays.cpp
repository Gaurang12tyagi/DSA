#include <iostream>
using namespace std;
class incr_star
{
public:
    void func1(int n)
    {

        for (int i = 0; i < n; i++)
        {
            for (int j = 0; j <= i; j++)
            {
                cout << "* ";
            }
            cout << endl;
        }
    }
};
int main()
{
    incr_star obj;
    cout << "ENTER THE NUMBER OF THE LINES YOU WANT TO PRINT" << endl;
    int n;
    cin >> n;
    obj.func1(n);

    return 0;
}