#include <iostream>
using namespace std;
class reverse
{
public:
    void reverse_array(int n, int arr[])
    {
        for (int i = n - 1; i >= 0; i--)
        {
            cout << arr[i];
        }
    }
};
int main()
{
    reverse obj;
    int n;
    cin >> n;
    int arr[n];
    for (int i = 0; i < n; i++)
    {
        cin >> arr[i];
    }
    obj.reverse_array(n, arr);

    return 0;
}