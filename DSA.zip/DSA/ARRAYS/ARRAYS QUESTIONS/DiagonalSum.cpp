
#include <iostream>
using namespace std;
class diagonal
{
public:
    void sum(int arr[3][3])
    {
        int sum = 0;
        for (int i = 0; i < 3; i++)
        {
            for (int j = 0; j < 3; j++)
            {
                if ((i + j) % 2 == 0)
                {
                    sum = sum + arr[i][j];
                }
            }
        }
        cout << sum;
    }
};
int main()
{
    diagonal obj;
    int arr[3][3];
    for (int i = 0; i < 4; i++)
    {
        for (int j = 0; j < 4; j++)
        {
            cin >> arr[i][j];
        }
    }
    obj.sum(arr);

    return 0;
}