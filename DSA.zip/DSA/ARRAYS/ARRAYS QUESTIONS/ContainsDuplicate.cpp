#include <iostream>
#include <vector>
using namespace std;
class Contain_dup
{
public:
    bool duplicate(int n, vector<int> v)
    {
        int count = 0;
        n = v.size();
        for (int i = 0; i < n - 1; i++)
        {
            for (int j = i + 1; j < n; j++)
            {
                if (v.at(i) == v.at(j))
                {
                    count++;
                }
            }
            if (count >= 1)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
};
int main()
{
    Contain_dup obj;
    int n;
    cin >> n;
    vector<int> vec(n);

    for (int i = 0; i < n; i++)
    {
        cin >> vec.at(i);
    }
    cout << obj.duplicate(n, vec);

    return 0;
}