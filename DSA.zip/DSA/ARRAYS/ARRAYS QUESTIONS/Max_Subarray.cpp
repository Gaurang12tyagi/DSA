#include <iostream>
using namespace std;
// THIS ALGO IS KNOWN AS KADANE'S ALGORITHM
class question3
{
public:
    int max_subarray(int n, int arr[])
    {
        int current_sum = 0;
        int max_sum = 0;
        for (int i = 0; i < n; i++)
        {
            current_sum = current_sum + arr[i];
            if (current_sum > max_sum)
            {
                max_sum = current_sum;
            }
            else if (current_sum < 0)
            {
                current_sum = 0;
            }
        }
        return max_sum;
    }
};
int main()
{
    question3 obj;
    int n;
    cin >> n;
    int arr[n];
    for (int i = 0; i < n; i++)
    {
        cin >> arr[i];
    }
    cout << obj.max_subarray(n, arr);

    return 0;
}