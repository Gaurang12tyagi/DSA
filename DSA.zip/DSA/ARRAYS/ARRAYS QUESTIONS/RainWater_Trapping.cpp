#include <iostream>

using namespace std;
class rwt
{
public:
    int raiwater(int n, int arr[])
    {
        int left_arr[n];
        int right_arr[n];
        left_arr[0] = arr[0];
        for (int i = 1; i < n; i++)
        {
            left_arr[i] = max(left_arr[i - 1], arr[i]);
        }
        right_arr[n - 1] = arr[n - 1];
        for (int i = n - 2; i >= 0; i--)
        {
            right_arr[i] = max(right_arr[i + 1], arr[i]);
        }
        int ans = 0;
        for (int i = 0; i < n; i++)
        {
            ans = ans + (min(left_arr[i], right_arr[i]) - arr[i]);
        }
        return ans;
    }
};
int main()
{
    rwt obj;
    cout << "ENTER NUMBER OF BLOCKS " << endl;
    int n;
    cin >> n;
    cout << "ENTER BLOCK HEIGHTS" << endl;
    int arr[n];
    for (int i = 0; i < n; i++)
    {
        cin >> arr[i];
    }
    cout << "TOTAL WATER IT CAN ACCOMODATE IS :" << obj.raiwater(n, arr) << "Lt.";

    return 0;
}