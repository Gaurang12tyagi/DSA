#include <iostream>
using namespace std;
class sum_min_max
{
public:
    int max_finder(int arr[], int n)
    {
        int max = arr[0];

        for (int i = 1; i < n; i++)
        {
            if (arr[i] > max)
            {
                max = arr[i];
            }
        }
        return max;
    }
    int min_finder(int arr[], int n)
    {
        int min = arr[0];

        for (int i = 1; i < n; i++)
        {
            if (arr[i] < min)
            {
                min = arr[i];
            }
        }
        return min;
    }
};
int main()
{
    int n;
    cin >> n;
    int arr[n];
    for (int i = 0; i < n; i++)
    {
        cin >> arr[i];
    }
    sum_min_max obj;
    cout << (obj.max_finder(arr, n) + obj.min_finder(arr, n));

    return 0;
}