#include <iostream>
using namespace std;
class paes
{
public:
    void product(int n, int arr[])
    {
        int start_mul[n];
        int end_mul[n];
        int result[n];
        start_mul[0] = arr[0];
        for (int i = 1; i < n; i++)
        {
            start_mul[i] = start_mul[i - 1] * arr[i];
        }
        end_mul[n - 1] = arr[n - 1];
        for (int i = n - 2; i >= 0; i--)
        {
            end_mul[i] = end_mul[i + 1] * arr[i];
        }
        result[0] = end_mul[1];
        result[n - 1] = start_mul[n - 2];
        for (int i = 1; i < n - 1; i++)
        {
            result[i] = start_mul[i - 1] * end_mul[i + 1];
        }
        for (int i = 0; i < n; i++)
        {
            cout << result[i] << "  ";
        }
    }
};
int main()
{
    paes obj;
    cout << "ENTER SIZE";
    int n;
    cin >> n;
    cout << "ENTER ELEMENT" << endl;
    int arr[n];
    for (int i = 0; i < n; i++)
    {
        cin >> arr[i];
    }
    obj.product(n, arr);

    return 0;
}