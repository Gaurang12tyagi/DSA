#include <iostream>
using namespace std;
class node
{
public:
    int data;
    node *left;
    node *right;
    node(int val)
    {
        this->data = val;
        this->left = NULL;
        this->right = NULL;
    }
};
// CREATION
node *insert(node *root, int val)
{
    if (root == NULL)
    {
        root = new node(val);
        return root;
    }
    if (val <= root->data)
    {
        root->left = insert(root->left, val);
    }
    else
    {
        root->right = insert(root->right, val);
    }
}

// IN ORDER TRAVERSAL
void inorder(node *root)
{
    if (root == NULL)
    {
        return;
    }
    inorder(root->left);
    cout << root->data << "  ";
    inorder(root->right);
}
// PART OF DELETION FUNCTION
// rightmost element in left subtree
node *inOrderPredessesor(node *root)
{
    root = root->left;
    while (root->right != NULL)
    {
        root = root->right;
    }
    return root;
}
node *del(node *root, int value)
{
    node *ipre;
    if (root == NULL)
    {
        return NULL;
    }
    // IF WE WANT TO DELETE LEAF NODE
    if (root->left == NULL && root->right == NULL)
    {
        free(root);
        return NULL;
    }
    if (value > root->data)
    {
        root->right = del(root->right, value);
    }
    else if (value < root->data)
    {
        root->left = del(root->left, value);
    }
    else
    {
        ipre = inOrderPredessesor(root);
        root->data = ipre->data;
        root->left = del(root->left, ipre->data);
    }
    return root;
}

int main()
{
    node *root = NULL;
    root = insert(root, 12);
    root = insert(root, 14);
    root = insert(root, 10);
    root = insert(root, 8);
    root = insert(root, 7);
    root = insert(root, 9);
    root = insert(root, 11);
    root = insert(root, 13);
    root = insert(root, 15);
    cout << "IN-ORDER TRAVERSAL IS:" << endl;
    inorder(root);
    cout << endl;
    cout << "AFTER DELETING 10 THE TREE WILL LOOK LIKE THIS:" << endl;
    del(root, 10);
    inorder(root);
    return 0;
}