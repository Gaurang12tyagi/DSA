#include <iostream>
using namespace std;
// insertion, deletion and searching in a binary bsearch tree has time complexity of O(H);
class Node
{
public:
    int data;
    Node *left;
    Node *right;
    Node(int val)
    {
        this->data = val;
        this->left = NULL;
        this->right = NULL;
    }
};
// CREATION
Node *insert(Node *root, int val)
{
    if (root == NULL)
    {
        root = new Node(val);
        return root;
    }
    if (val <= root->data)
    {
        root->left = insert(root->left, val);
    }
    else
    {
        root->right = insert(root->right, val);
    }
}

// PRE ORDER TRAVERSAL
void preorder(Node *root)
{
    if (root == NULL)
    {
        return;
    }
    cout << root->data << "  ";
    preorder(root->left);
    preorder(root->right);
}
// IN ORDER TRAVERSAL
void inorder(Node *root)
{
    if (root == NULL)
    {
        return;
    }
    inorder(root->left);
    cout << root->data << "  ";
    inorder(root->right);
}
// POST ORDER TRAVERSAL
void postorder(Node *root)
{
    if (root == NULL)
    {
        return;
    }
    postorder(root->left);
    postorder(root->right);
    cout << root->data << "  ";
}

int main()
{
    Node *root = NULL;
    root = insert(root, 12);
    root = insert(root, 9);
    root = insert(root, 7);
    root = insert(root, 10);
    root = insert(root, 16);
    root = insert(root, 13);
    root = insert(root, 18);
    cout << "PRE-ORDER TRAVERSAL IS:" << endl;
    preorder(root);
    cout << endl;
    cout << "POST-ORDER TRAVERSAL IS:" << endl;
    postorder(root);
    cout << endl;
    cout << "IN-ORDER TRAVERSAL IS:" << endl;
    inorder(root);
    return 0;
}