#include <iostream>
using namespace std;
class node
{
public:
    node *left;
    node *right;
    int data;
    node(int val)
    {
        this->data = val;
        this->left = NULL;
        this->right = NULL;
    }
};
node *creation(node *root, int val)
{
    node *new_root = new node(val);
    if (root == NULL)
    {
        root = new_root;
        return root;
    }
    if (val <= root->data)
    {
        root->left = creation(root->left, val);
    }
    else
    {
        root->right = creation(root->right, val);
    }
}
void inorder(node *root)
{
    if (root == NULL)
    {
        return;
    }

    inorder(root->left);
    cout << root->data << "  ";
    inorder(root->right);
}
int search(node *root, int key)
{
    // Base Cases: root is null or key is present at root
    if (root == NULL || root->data == key)
        return root->data;

    // Key is greater than root's key
    else if (root->data < key)
        return search(root->right, key);

    // Key is smaller than root's key

    else
        return search(root->left, key);
}

int main()
{
    node *root = NULL;
    root = creation(root, 12);
    root = creation(root, 9);
    root = creation(root, 7);
    root = creation(root, 10);
    root = creation(root, 16);
    root = creation(root, 13);
    root = creation(root, 18);
    root = creation(root, 22);
    root = creation(root, 17);
    cout << "INORDER TRAVERSAL IS :" << endl;
    inorder(root);
    cout << endl;
    cout << "ENTER THE ELEMENT TO SEARCH" << endl;
    int key;
    cin >> key;
    cout << "IT IS : " << search(root, key);

    return 0;
}