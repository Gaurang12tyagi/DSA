#include <iostream>
#include <vector> //CREATES DYNAMIC ARRAY - INSERTION AND DELETION AT BACK
using namespace std;
int main()
{
    vector<string> v;
    v.push_back("ANMOL");
    v.push_back("GAURANG");
    v.push_back("PARAS");
    v.push_back("ANCHAL");
    v.push_back("HIMANSHU");
    v.push_back("KAPIL");
    v.push_back("SANTA");
    v.emplace for (int i = 0; i < v.size(); i++)
    {
        cout << v.at(i) + "  ";
    }

    return 0;
}