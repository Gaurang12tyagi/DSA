#include <iostream>
#include <map>
using namespace std;
class maps
{
public:
    void print(map<int, string> mp)
    {
        cout << mp.size() << endl;
        for (auto pr : mp)
        {
            cout << pr.first << " " << pr.second << endl;
        }
    }
};
int main()
{
    maps obj;

    map<int, string> m;
    m[1] = "abc";
    m[2] = "def";
    m[3] = "ghi";
    m[4] = "jkl";
    obj.print(m);

    return 0;
}