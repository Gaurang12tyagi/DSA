#include <iostream>
using namespace std;
#define n 20
class queue
{
    int *arr;
    int front;
    int back;

public:
    queue()
    {
        arr = new int[n];
        front = -1;
        back = -1;
    }
    void push(int x)
    {
        if (back == n - 1)
        {
            cout << "QUEUE OVERFLOW" << endl;
            return;
        }
        back++;
        arr[back] = x;
        // only for first element
        if (front == -1)
        {
            front++;
        }
    }
    void pop()
    {
        if (front == -1 || front > back)
        {
            cout << "NO ELEMENTS ARE PRESENT TO POP" << endl;
            return;
        }
        front++;
    }
    int peek()
    {
        if (front == -1 || front > back)
        {
            cout << "NO ELEMENTS ARE PRESENT TO POP" << endl;
            return -1;
        }
        return arr[front];
    }
    bool empty()
    {
        if (front == -1 || front > back)
        {
            return true;
        }
        return false;
    }
};
int main()
{
    queue q;
    cout << "INSERTING ELEMENTS" << endl;
    q.push(2);
    q.push(4);
    q.push(6);
    q.push(8);
    q.push(10);
    q.push(12);
    q.push(14);
    cout << "INSERTION COMPLETE" << endl;
    cout << "FRONT ELEMENTS IN QUEUE IS :" << endl;
    cout << q.peek() << endl;
    cout << "AFTER POPPING UP 4 ELEMETS :" << endl;
    q.pop();
    q.pop();
    q.pop();
    q.pop();
    cout << "FRONT ELEMENT IN QUEUE IS :" << endl;
    cout << q.peek() << endl;

    return 0;
}