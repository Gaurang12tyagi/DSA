#include <iostream>
using namespace std;
class node
{
public:
    int data;
    node *next;
    node(int val)
    {
        this->data = val;
        this->next = NULL;
    }
};
class queue
{
public:
    node *front;
    node *back;
    queue()
    {
        front = NULL;
        back = NULL;
    }
    void enqueue(int data)
    {
        node *temp = new node(data);
        if (front == NULL && back == NULL)
        {

            front = back = temp;

            return;
        }
        back->next = temp;
        back = temp;
    }
    void dequeue()
    {
        node *temp = front;
        if (front == NULL)
        {

            printf("Queue is Empty\n");

            return;
        }
        if (front == back)
        {

            front = back = NULL;
        }
        else
        {

            front = front->next;
        }

        free(temp);
    }
    int peek()
    {
        if (front == NULL)
        {

            printf("Queue is empty\n");
        }
        return front->data;
    }
    void print()
    {
        node *temp = front;
        while (temp != NULL)
        {
            cout << temp->data << " ";
            temp = temp->next;
        }
    }
};
int main()
{
    queue q;
    q.enqueue(5);
    q.enqueue(6);
    q.enqueue(7);
    q.enqueue(8);
    q.enqueue(9);
    q.enqueue(10);
    q.enqueue(12);
    q.print();
    q.dequeue();
    cout << endl;
    q.print();

    return 0;
}