#include <iostream>
#include <vector>
using namespace std;
class rev
{
public:
    void reverse(string str)
    {
        int n = str.length();
        string new_str = "";

        for (int i = n - 1; i >= 0; i--)
        {
            new_str = new_str + str.at(i);
        }
        cout << new_str;
    }
};

int main()
{
    rev obj;
    string str;
    cin >> str;

    obj.reverse(str);

    return 0;
}