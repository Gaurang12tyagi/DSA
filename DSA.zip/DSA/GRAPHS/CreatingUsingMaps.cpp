#include <iostream>
#include <unordered_map>
#include <list>
using namespace std;

class graphs
{
public:
    unordered_map<int, list<int>> adj;
    void addEdege(int u, int v, bool directed)
    {
        adj[u].push_back(v);
        if (directed == 0)
        {
            adj[v].push_back(u);
        }
    }
    void print()
    {
        for (auto i : adj)
        {
            cout << i.first << "  ->  ";
            for (auto j : i.second)
            {
                cout << j << ", ";
            }
            cout << endl;
        }
    }
};
int main()
{
    graphs obj;
    int u, v;
    cout << "ENTER VERTEX" << endl;
    cin >> u;
    cout << "ENTER EDGE" << endl;
    cin >> v;
    for (int i = 0; i < v; i++)
    {
        int v, e;
        cin >> v >> e;
        obj.addEdege(v, e, 0);
    }
    obj.print();

    return 0;
}