
#include <bits/stdc++.h>
using namespace std;
class bfs_sol
{
public:
    vector<int> bfs_traversal(int V, vector<int> adj[])
    {
        int vis[V] = {0};
        vis[0] = 1;
        queue<int> q;
        q.push(0);
        vector<int> bfs;
        while (!q.empty())
        {
            int node = q.front();
            q.pop();
            bfs.push_back(node);
            for (auto it : adj[node])
            {
                if (!vis[it])
                {
                    vis[it] = 1;
                    q.push(it);
                }
            }
        }
        return bfs;
    }
};
void addEdge(vector<int> adj[], int u, int v)
{
    adj[u].push_back(v);
    adj[v].push_back(u);
}
void printAns(vector<int> &ans)
{
    for (int i = 0; i < ans.size(); i++)
    {
        cout << ans[i] << "  ";
    }
}
int main()
{
    bfs_sol obj;
    // ARRAYS OF VECTOR IS USED TO CREATE ADJACENCY LIST
    int e1, e2;
    cout << "ENTER THE NUMBER OF VERTICES ::" << endl;
    int n;
    cin >> n;
    cout << "ENTER CONNECTIONS OF THE EDGES ::" << endl;
    vector<int> adj[6];
    for (int i = 0; i < n; i++)
    {
        cin >> e1 >> e2;

        addEdge(adj, e1, e2);
    }

    vector<int> ans = obj.bfs_traversal(n, adj);
    printAns(ans);
    return 0;
}