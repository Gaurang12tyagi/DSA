#include <iostream>
using namespace std;
// step 2.
int partition(int arr[], int low, int high)
{
    int pivot = arr[high];
    int helper = low - 1;
    for (int i = low; i < high; i++)
    {
        if (arr[i] < pivot)
        {
            helper++;
            int temp = arr[helper];
            arr[helper] = arr[i];
            arr[i] = temp;
        }
    }
    helper++;
    int temp = arr[helper];
    arr[helper] = pivot;
    arr[high] = temp;
    return helper;
}
// step 1.
void quickSort(int arr[], int low, int high)
{
    if (low < high)
    {
        int pivot_indx = partition(arr, low, high);
        quickSort(arr, low, pivot_indx - 1);  // pivot se chotte num. ke liye
        quickSort(arr, pivot_indx + 1, high); // pivot se chotte num. ke liye
    }
}
int main()
{
    cout << ("ENTER SIZE \n");
    int n;
    cin >> n;
    int array[n];
    printf("ENTER ELEMENTS \n");
    for (int i = 0; i < n; i++)
    {
        cin >> array[i];
    }
    cout << "AFTER SORTING" << endl;
    quickSort(array, 0, n - 1);
    for (int i = 0; i < n; i++)
    {
        cout << array[i] << "  ";
    }
    return 0;
}
