#include <iostream>
using namespace std;
int hrapsort(int a[], int n)
{
    int temp;
    int last = n;
    while (last > 0)
    {
    }
}
int main()
{

    return 0;
}