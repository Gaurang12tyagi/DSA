#include <iostream>
using namespace std;
void selection(int n, int arr[])
{
    int temp = 0;
    for (int i = 0; i < n - 1; i++)
    {
        for (int j = i + 1; j < n; j++)
        {
            if (arr[i] > arr[j])
            {
                temp = arr[i];
                arr[i] = arr[j];
                arr[j] = temp;
            }
        }
    }
    cout << " SORTED ARRAY :" << endl;
    for (int i = 0; i < n; i++)
    {
        cout << arr[i] << " ";
    }
}
int main()
{
    cout << "ENTER ARRAY SIZE ::" << endl;
    int n;
    cin >> n;
    cout << "ENTER AYYAY VALUES ::" << endl;
    int arr[n];
    for (int i = 0; i < n; i++)
    {
        cin >> arr[i];
    }
    selection(n, arr);
    return 0;
}