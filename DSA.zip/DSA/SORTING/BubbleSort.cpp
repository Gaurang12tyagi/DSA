#include <iostream>
using namespace std;
void bubble(int n, int arr[])
{
    // complexity O(n^2)
    int counter = 0;
    int temp = 0;
    while (counter < n)
    {
        for (int i = 0; i < n - 1; i++)
        {
            if (arr[i] > arr[i + 1])
            {
                temp = arr[i];
                arr[i] = arr[i + 1];
                arr[i + 1] = temp;
            }
        }
        counter++;
    }
    cout << "SORTED ARRAY"
         << endl;
    for (int i = 0; i < n; i++)
    {
        cout << arr[i] << " ";
    }
}
int main()
{
    cout << "ENTER ARRAY SIZE ::" << endl;
    int n;
    cin >> n;
    cout << "ENTER AYYAY VALUES ::" << endl;
    int arr[n];
    for (int i = 0; i < n; i++)
    {
        cin >> arr[i];
    }
    bubble(n, arr);
    return 0;
}