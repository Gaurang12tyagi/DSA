#include <iostream>
using namespace std;
void conquer(int arr[], int low, int mid, int high)
{
    int merging_array[high - low + 1];
    int tracker_1 = low;
    int tracker_2 = mid + 1;
    int x = 0;
    while (tracker_1 <= mid && tracker_2 <= high)
    {
        if (arr[tracker_1] <= arr[tracker_2])
        {
            merging_array[x] = arr[tracker_1];
            tracker_1++;
            x++;
        }
        else
        {

            merging_array[x] = arr[tracker_2];
            tracker_2++;
            x++;
        }
        while (tracker_1 <= mid)
        {
            merging_array[x] = arr[tracker_1];
            x++;
            tracker_1++;
        }

        while (tracker_2 <= high)
        {
            merging_array[x] = arr[tracker_2];
            x++;
            tracker_2++;
        }
    }
    for (int i = 0, j = low; i < sizeof(merging_array) / sizeof(int); i++, j++)
    { // i for merging array and j for
        // normal tacking.
        arr[j] = merging_array[i];
    }
}
void divide(int arr[], int low, int high)
{

    if (low >= high)
    {
        // cout << "ALREADY SORTED OR UNABLE TO SORT";
        return;
    }
    int mid = low + (high - low) / 2;
    divide(arr, low, mid);
    divide(arr, mid + 1, high);
    conquer(arr, low, mid, high);
}
int main()
{
    cout << "ENTER SIZE \n";
    int n;
    cin >> n;
    int array[n];
    cout << "ENTER ELEMENTS \n";
    for (int i = 0; i < n; i++)
    {
        cin >> array[i];
    }
    cout << "AFTER SORTING ARRAY IS : ";
    divide(array, 0, n - 1);
    for (int i = 0; i < n; i++)
    {
        cout << array[i];
    }
    return 0;
}