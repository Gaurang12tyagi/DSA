st.pop();
    // st.pop();
    // st.pop();