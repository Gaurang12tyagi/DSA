#include <iostream>
using namespace std;
#define n 100
class stack
{
    int *arr;
    int top;

public:
    stack()
    {
        arr = new int[n];
        top = -1;
    }
    // PUSH OPERATION
    void push(int x)
    {
        if (top == n - 1)
        {
            cout << "STACK OVERFLOW " << endl;
            return;
        }
        top++;
        arr[top] = x;
    }
    // POP OPERATION
    void pop()
    {
        if (top == -1)
        {
            cout << "STACK UNDERFLOW" << endl;
            return;
        }
        top--;
    }
    int peek()
    {
        if (top == -1)
        {
            cout << " NO ELEMENTS TO SHOW" << endl;
            return -1;
        }
        else
        {
            return arr[top];
        }
    }
    bool empty()
    {
        if (top == -1)
        {
            return true;
        }
        return false;
    }
};
int main()
{
    stack st;
    st.push(2);
    st.push(4);
    st.push(6);
    st.push(8);
    st.push(10);
    st.push(12);
    st.push(14);

    cout << "BEFORE REMOVING TOP ELEMENT :" << endl;
    cout << st.peek() << endl;
    cout << "AFTER REMOVING TOP ELEMENT :" << endl;
    st.pop();
    cout << st.peek() << endl;
    st.pop();
    st.pop();
    st.pop();
    st.pop();
    st.pop();
    st.pop();
    st.pop();

    return 0;
}