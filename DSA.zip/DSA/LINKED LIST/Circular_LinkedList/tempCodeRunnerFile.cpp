using namespace std;
class Node
{
public:
    int data;
    Node *next;
    Node(int val)
    {
        this->data = val;
    }
};
void insertion(Node *&head, int val)
{
    Node *nya_node = new Node(val);
    if (head == NULL)
    {
        head = nya_node;
        return;
    }

    Node *ptr = head;
    while (ptr->next != NULL)
    {
        ptr = ptr->next;
    }
    ptr->next = nya_node;
}