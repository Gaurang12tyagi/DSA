#include <iostream>
using namespace std;
class Node
{
public:
    int data;
    Node *next;
    Node(int val)
    {
        this->data = val;
        this->next = NULL;
    }
};
// INSERION AT THE START
void insertion(Node *&head, int val)
{
    Node *nya_node = new Node(val);
    if (head == NULL)
    {
        head = nya_node;
        nya_node->next = head;
        return;
    }

    Node *ptr = head;
    while (ptr->next != head)
    {
        ptr = ptr->next;
    }
    ptr->next = nya_node;
    nya_node->next = head;
    head = nya_node;
}

// traversal
void traversal(Node *head)
{
    Node *ptr = head;
    while (ptr->next != head)
    {
        cout << ptr->data << " ";
        ptr = ptr->next;
    }
    cout << ptr->data;
}
int main()
{

    Node *head = NULL;

    insertion(head, 2);
    insertion(head, 4);
    insertion(head, 6);
    insertion(head, 8);
    insertion(head, 10);
    insertion(head, 12);
    insertion(head, 14);
    traversal(head);
    cout << "AFTER INSERTING AT START" << endl;
    insert_at_begining(head, 0);
    traversal(head);

    return 0;
}