#include <iostream>
using namespace std;
class node
{
public:
    int data;
    node *next;
    node(int val)
    {
        this->data = val;
        this->next = NULL;
    }
};
void create(node *&head, int data)
{
    node *new_node = new node(data);
    if (head == NULL)
    {
        head = new_node;
        return;
    }
    node *ptr = head;
    while (ptr->next != NULL)
    {
        ptr = ptr->next;
    }
    ptr->next = new_node;
}
void traversal(node *head)
{
    node *ptr = head;
    while (ptr != NULL)
    {
        cout << ptr->data << " ";
        ptr = ptr->next;
    }
}
void searching(node *head, int index)
{
    node *ptr = head;
    int i = 0;
    while (i < index)
    {
        ptr = ptr->next;
        i++;
    }
    cout << ptr->data;
}

int main()
{
    node *head = NULL;
    cout << "SHOWING ALL THE LINKED LIST" << endl;
    create(head, 2);
    create(head, 4);
    create(head, 6);
    create(head, 8);
    create(head, 10);
    create(head, 12);
    create(head, 14);
    traversal(head);
    cout << endl;
    cout << "SEARCHING THE ELEMENT"
         << endl;
    searching(head, 4);

    return 0;
}