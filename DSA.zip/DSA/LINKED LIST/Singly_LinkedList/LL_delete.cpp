#include <iostream>
using namespace std;
class node
{
public:
    int data;
    node *next; // pinter to the node class
    node(int val)
    {
        this->data = val;
        this->next = NULL;
    }
};
void insertion(node *&head, int val)
{
    node *nya_node = new node(val);
    if (head == NULL)
    {
        head = nya_node;
        return;
    }

    node *ptr = head;
    while (ptr->next != NULL)
    {
        ptr = ptr->next;
    }
    ptr->next = nya_node;
}

// DELETE AT START
void start_delete(node *&head)
{

    node *ptr = head;
    head = head->next;
    free(ptr);
}
// DELETE AT END
void end_delete(node *&head)
{

    node *ptr = head->next;
    node *prev = head;
    while (ptr->next != NULL)
    {
        ptr = ptr->next;
        prev = prev->next;
    }
    prev->next = NULL;
    free(ptr);
}
// DELETE AT INDEX
void index_delete(node *&head, int index)
{
    node *ptr = head->next;
    node *prev = head;
    int i = 0;
    while (i != index - 1)
    {
        ptr = ptr->next;
        prev = prev->next;
        i++;
    }
    prev->next = ptr->next;
    free(ptr);
}
void display(node *head)
{
    node *ptr = head;
    do
    {
        cout << ptr->data << " ";
        ptr = ptr->next;
    } while (ptr->next != NULL);
    cout << ptr->data;
}
int main()
{
    node *head = NULL;
    insertion(head, 2);
    insertion(head, 4);
    insertion(head, 6);
    insertion(head, 8);
    insertion(head, 10);
    insertion(head, 12);
    insertion(head, 14);
    display(head);
    cout << endl;
    cout << "DELTE AT START" << endl;
    start_delete(head);
    display(head);
    cout << endl;
    cout << "DELTE AT END" << endl;
    end_delete(head);
    display(head);
    cout << endl;
    cout << "DELTE AT INDEX" << endl;
    index_delete(head, 3);
    display(head);
    return 0;
}