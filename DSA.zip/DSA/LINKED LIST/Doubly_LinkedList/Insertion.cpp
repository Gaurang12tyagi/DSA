#include <iostream>
using namespace std;
class node
{
public:
    int data;
    node *next;
    node *prev;
    node(int val)
    {
        this->data = val;
        this->next = NULL;
        this->prev = NULL;
    }
};
void insertion(node *&head, int value)
{
    node *new_node = new node(value);
    node *ptr = head;
    if (head == NULL)
    {
        head = new_node;
        return;
    }
    while (ptr->next != NULL)

    {

        ptr = ptr->next;
    }
    ptr->next = new_node;
}
// INSERT AT INDEX
void index_insert(node *&head, int index, int data)
{
    node *new_node = new node(data);
    node *ptr = head;
    int i = 0;
    while (i < index)
    {
        ptr = ptr->next;
        i++;
    }
    new_node->next = ptr->next;
    ptr->next = new_node;

    return;
}

// INSERT AT START
void start_insert(node *&head, int val)
{
    node *ptr = head;
    node *new_node = new node(val);
    if (head == NULL)
    {
        head = new_node;
        return;
    }
    new_node->next = head;
    head = new_node;
}
void display(node *head)
{
    node *ptr = head;
    do
    {
        cout << ptr->data << " ";
        ptr = ptr->next;
    } while (ptr->next != NULL);
    cout << ptr->data;
}
int main()

{
    node *head = NULL;
    insertion(head, 2);
    insertion(head, 4);
    insertion(head, 6);
    insertion(head, 8);
    insertion(head, 10);
    insertion(head, 12);
    insertion(head, 14);
    insertion(head, 16);
    insertion(head, 18);
    display(head);
    cout << endl
         << "after inserting at index" << endl;
    index_insert(head, 3, 9);
    display(head);
    cout << endl
         << "after inserting at start" << endl;
    start_insert(head, 0);
    display(head);

    return 0;
}