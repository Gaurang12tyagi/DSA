#include <iostream>
using namespace std;
class node
{
public:
    string name;
    int roll;
    int marks;
    node *next;
    node(string n, int r, int m)
    {

        this->name = n;
        this->roll = r;
        this->marks = m;
        this->next = NULL;
    }
};
void insert(node *&head, string naam, int num, int mark)
{
    node *new_node = new node(naam, num, mark);
    if (head == NULL)
    {
        head = new_node;
        return;
    }
    node *ptr = head;
    while (ptr->next != NULL)
    {
        ptr = ptr->next;
    }
    ptr->next = new_node;
}
void calculate(node *head)
{
    float percentage;
    node *ptr = head;
    while (ptr != NULL)
    {
        percentage = (ptr->marks) * 0.2;
        cout << "Percentage of " << ptr->name << " is " << percentage << "  % " << endl;
        ptr = ptr->next;
    }
}

void display(node *head)
{
    node *ptr = head;
    while (ptr != NULL)
    {
        cout << ptr->roll << " : " << ptr->name << " : " << ptr->marks << endl;
        ptr = ptr->next;
    }
}
int main()
{
    node *head = NULL;
    insert(head, "anmol", 1, 350);
    insert(head, "gaurang", 2, 400);
    insert(head, "paras", 3, 500);
    insert(head, "yash", 4, 475);
    insert(head, "himanshu", 5, 450);
    display(head);
    calculate(head);

    return 0;
}