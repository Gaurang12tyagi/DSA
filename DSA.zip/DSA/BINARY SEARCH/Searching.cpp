#include <iostream>
using namespace std;
int binarary_search(int arr[], int size, int val)
{
    int start = 0;
    int end = size - 1;
    while (start <= end)

    {
        int mid = start + (end - start) / 2;

        if (arr[mid] == val)
        {
            return mid;
        }
        else if (arr[mid] < val)
        {
            start = mid + 1;
        }
        else
        {
            end = start - 1;
        }
    }
    return -1;
}
int main()
{
    cout << "ENTER AYYAY SIZE :" << endl;
    int n;
    cin >> n;
    cout << "ENTER ARRAY VALUES :" << endl;
    int array[n];
    for (int i = 0; i < n; i++)
    {
        cin >> array[i];
    }
    cout << "ENTER VALUE TO BE SEARCHED :" << endl;
    int v;
    cin >> v;
    cout << "NUMBER IS PRESENT AT " << binarary_search(array, n, v) << " INDEX";
    return 0;
}