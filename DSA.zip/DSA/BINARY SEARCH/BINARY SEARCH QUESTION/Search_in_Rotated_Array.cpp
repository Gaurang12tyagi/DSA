#include <iostream>
using namespace std;
class rotated
{
public:
    int search(int n, int arr[], int k)
    {

        int low = 0;
        int high = n - 1;
        while (low <= high)
        {
            int mid = high + (low - high) / 2;
            if (arr[mid] == k)
            {
                return mid;
            }
            else if (arr[low] < arr[mid]) // left part sorted
            {

                if (k >= arr[low] && k < arr[mid])
                {
                    high = mid - 1;
                }
                else
                {
                    low = mid + 1;
                }
            }
            else // right part sorted;
            {
                if (k > arr[mid] && k <= arr[high])
                {
                    low = mid + 1;
                }
                else
                {
                    high = mid - 1;
                }
            }
        }
        return -1;
    }
};
int main()
{
    rotated obj;
    cout << "ENTER SIZE OF ARRAY" << endl;
    int n;
    cin >> n;
    cout << "ENTER ARRAY ELEMENTS" << endl;
    int arr[n];
    for (int i = 0; i < n; i++)
    {
        cin >> arr[i];
    }
    cout << "ENTER KEY VALUE" << endl;
    int k;
    cin >> k;

    cout << obj.search(n, arr, k);
    return 0;
}