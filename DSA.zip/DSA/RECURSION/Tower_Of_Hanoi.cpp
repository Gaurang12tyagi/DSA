#include <iostream>
using namespace std;
class GFG
{
public:
    void towerOfHanoi(int n, char from_rod, char to_rod, char aux_rod)
    {
        if (n == 1)
        {
            cout << "Move disk 1 from rod " << from_rod << " to rod " << to_rod << endl;
            return;
        }
        towerOfHanoi(n - 1, from_rod, aux_rod, to_rod);
        cout << "Move disk " << n << " from rod " << from_rod << " to rod " << to_rod << endl;
        towerOfHanoi(n - 1, aux_rod, to_rod, from_rod);
    }
};
int main()
{
    GFG obj;

    cout << "ENTER THE NUMBER OF RINGS :";
    int n;
    cin >> n;
    cout << "ENTER THE SOURCE :";
    char A;
    cin >> A;
    cout << "ENTER THE DESTINATION :";
    char B;
    cin >> B;
    cout << "ENTER THE HELPING RODE :";
    char C;
    cin >> B;
    obj.towerOfHanoi(n, A, B, C);

    return 0;
}
