#include <iostream>
using namespace std;
class recursive
{
public:
    int x = 1;
    void print()
    {
        if (x > 10)
        {
            return;
        }
        cout << x << "  ";
        x++;
        print();
    }
};
int main()
{
    recursive r;
    r.print();

    return 0;
}